<?php
	// Generales
	function getRequerido()
	{
		return 'Este campo es requerido...';
	}
	function getErrorRequeridos()
	{
		return 'Falto llenar campos requeridos';
	}
	function getMsgTitulo()
	{
		return 'Resultado de la Solicitud';
	}
	
	//Compa�ias
	function getCiaSuccesMsg()
	{
		return 'Compa&ntilde;&iacute;a Guardada Correctamente.';
	}
	function getCiaUpdtMsg()
	{
		return 'Compa&ntilde;&iacute;a Actualizada Correctamente.';
	}
	function getCiaDelMsg()
	{
		return 'Compa&ntilde;&iacute;a Eliminada Correctamente.';
	}
	function getCiaDelErrorMsg()
	{
		return 'Es necesario seleccionar una Compa&ntilde;&iacute;a ...';
	}
	function getMsgCiaAsig()
	{
		return 'Compa&ntilde;&iacute;a(s) Asignada(s).';
	}

	//Plazas
	function getPlazaSuccessMsg() {
		return 'Plaza Creada Correctamente.';
	}
	function getPlazaUpdMsg() {
		return 'Plaza Actualizada Correctamente.';
	}

	//Paises
	function getPaisSuccessMsg(){
		return 'Pais Creado Correctamente';
	}
	function getPaisUpdateMsg(){
		return 'Pais Actualizado Correctamente';
	}
	function getPaisDeleteMsg(){
		return 'Pais Borrado Correctamente';
	}
	function getPaisDuplicateMsg(){
		return 'Pais Ya Existente';
	}

	//Estados
	function getEstadoSuccessMsg(){
		return 'Estado Creado Correctamente';
	}
	function getEstadoUpdateMsg(){
		return 'Estado Actualizado Correctamente';
	}
	function getEstadoDeleteMsg(){
		return 'Estado Borrado Correctamente';
	}
	function getEstadoDuplicateMsg(){
		return 'Estado Ya Existente';
	}

	//Municipios
	function getMunicipioSuccessMsg(){
		return 'Municipio Creado Correctamente';
	}
	function getMunicipioUpdateMsg(){
		return 'Municipio Actualizado Correctamente';
	}
	function getMunicipioDeleteMsg(){
		return 'Municipio Borrado Correctamente';
	}
	function getMunicipioDuplicateMsg(){
		return 'Municipio Ya Existente';
	}

	//Colonia
	function getColoniaSuccessMsg(){
		return 'Colonia Creada Correctamente';
	}
	function getColoniaUpdateMsg(){
		return 'Colonia Actualizada Correctamente';
	}
	function getColoniaDeleteMsg(){
		return 'Colonia Borrada Correctamente';
	}
	function getColoniaDuplicateMsg(){
		return 'Colonia Ya Existente';
	}

	//Regiones
	function getRegionSuccessMsg(){
		return 'Region Creada Correctamente';
	}
	function getRegionUpdateMsg(){
		return 'Region Actualizada Correctamente';
	}
	function getRegionDeleteMsg(){
		return 'Region Borrada Correctamente';
	}

	//Generales
	function getGeneralesSuccessMsg(){
		return 'Registro Creado Correctamente';
	}
	function getGeneralesUpdateMsg(){
		return 'Registro Actualizado Correctamente';
	}
	function getGeneralesDeleteMsg(){
		return 'Registro Borrado Correctamente';
	}

	//Tractores
	function getTractoresSuccessMsg(){
		return 'Tractor Creado Correctamente';
	}
	function getTractoresUpdateMsg(){
		return 'Tractor Actualizado Correctamente';
	}
	function getTractoresDeleteMsg(){
		return 'Tractor Borrado Correctamente';
	}
	//--Errores Tractores
	//Error No 1062
	function getTractoresDuplicateMsg(){
		return 'Existe otro tractor con el mismo No. serie o placas';
	}

	//Choferes
	function getChoferesSuccessMsg(){
		return 'Chofer Creado Correctamente';
	}
	function getChoferesUpdateMsg(){
		return 'Chofer Actualizado Correctamente';
	}
	function getChoferesDeleteMsg(){
		return 'Chofer Borrado Correctamente';
	}
	//--Errores Choferes
	//Error No 1062
	function getChoferesDuplicateMsg(){
		return 'Existe otro chofer con la misma clave o licencia';
	}

	//Tarifas
	function getTarifasSuccessMsg(){
		return 'Tarifa Creada Correctamente';
	}
	function getTarifasUpdateMsg(){
		return 'Tarifa Actualizada Correctamente';
	}
	function getTarifasDeleteMsg(){
		return 'Tarifa Borrada Correctamente';
	}

	//Distribuidores
	function getDistribuidoresSuccessMsg(){
		return 'Distribuidor Creado Correctamente';
	}
	function getDistribuidoresUpdateMsg(){
		return 'Distribuidor Actualizado Correctamente';
	}
	function getDistribuidoresDeleteMsg(){
		return 'Distribuidor Borrado Correctamente';
	}
	function getDistribuidoresUpdateNoDirectionUpdMsg(){
		return 'Distribuidor Actualizado Correctamente.<br>No hubo direcciones a actualizar.';	
	}

	//Distribuidores Especiales
	function getDistEspecialSuccessMsg($tipo){
		switch ($tipo) {
			case 'DE':
				return 'Destino Especial Creado Correctamente';
				break;
			case 'CD':
				return 'Centro de Distribucion Creado Correctamente';
				break;
			case 'PA':
				return 'Patio Creado Correctamente';
				break;
			default:
				return '';
				break;
		}
	}
	function getDistEspecialUpdMsg($tipo){
		switch ($tipo) {
			case 'DE':
				return 'Destino Especial Actualizado Correctamente';
				break;
			case 'CD':
				return 'Centro de Distribucion Actualizado Correctamente';
				break;
			case 'PA':
				return 'Patio Actualizado Correctamente';
				break;
			default:
				return '';
				break;
		}
	}

	//Direcciones
	function getDireccionesSuccessMsg($cuant){
		if($cuant == 1)
			return 'Direcciones Creadas Correctamente';
		else
			return 'Direccion Creada Correctamente';
	}
	function getDireccionesUpdateMsg($cuant){
		if ($cuant == 1)
			return 'Direcciones Actualizadas Correctamente';
		else
			return 'Direccion Actualizada Correctamente';
	}
	function getDireccionesDeleteMsg($cuant){
		if ($cuant == 1)
			return 'Direcciones Borradas Correctamente';
		else
			return 'Direccion Borrada Correctamente';
	}
	//--Errores Distribuidores
	//Error No 1062
	function getDistribuidoresDuplicateMsg(){
		return 'Centro Distribucion Duplicado';
	}

	//Colores
	function getColoresSuccessMsg(){
		return 'Color Creado Correctamente';
	}
	function getColoresUpdateMsg(){
		return 'Color Actualizado Correctamente';
	}
	function getColoresDeleteMsg(){
		return 'Color Borrado Correctamente';
	}
	//--Errores Colores
	//Error No 1062
	function getColoresDuplicateMsg(){
		return 'Esta Marca ya esta asignada a este color';
	}

	//Proveedores
	function getProveedoresSuccessMsg(){
		return 'Proveedor Creado Correctamente';
	}
	function getProveedoresUpdateMsg(){
		return 'Proveedor Actualizado Correctamente';
	}
	function getProveedoresDeleteMsg(){
		return 'Proveedor Borrado Correctamente';
	}

	//Gastos Tractor
	function getGastosTractorSuccessMsg(){
		return 'Gasto de Tractor Creado Correctamente';
	}
	function getGastosTractorUpdateMsg(){
		return 'Gasto de Tractor Actualizado Correctamente';
	}
	function getGastosTractorDeleteMsg(){
		return 'Gasto de Tractor Borrado Correctamente';
	}

	//Marcas Unidades
	function getMarcasUnidadesSuccessMsg(){
		return 'Marca Creada Correctamente';
	}
	function getMarcasUnidadesUpdateMsg(){
		return 'Marca Actualizada Correctamente';
	}
	function getMarcasUnidadesDeleteMsg(){
		return 'Marca Borrada Correctamente';
	}

	//Clasificacion Marca
	function getClasificacionMarcaSuccessMsg(){
		return 'Clasificacion de la Marca Creada Correctamente';
	}
	function getClasificacionMarcaUpdateMsg(){
		return 'Clasificacion de la Marca Actualizada Correctamente';
	}
	function getClasificacionMarcaDeleteMsg(){
		return 'Clasificacion de la Marca Borrada Correctamente';
	}

	//Conceptos Centros
	function getConceptosCentrosSuccessMsg(){
		return 'Concepto de Distribuidor Creado Correctamente';
	}
	function getConceptosCentrosUpdateMsg(){
		return 'Concepto de Distribuidor Actualizado Correctamente';
	}
	function getConceptosCentrosDeleteMsg(){
		return 'Concepto de Distribuidor Borrado Correctamente';
	}
	//Error No 1062
	function getConceptosCentrosDuplicateMsg(){
		return 'Este Distribuidor ya tiene un concepto igual';
	}

	//Simbolos Unidades
	function getSimbolosUnidadesSuccessMsg(){
		return 'Simbolo de Unidad Creado Correctamente';
	}
	function getSimbolosUnidadesUpdateMsg(){
		return 'Simbolo de Unidad Actualizado Correctamente';
	}
	function getSimbolosUnidadesDeleteMsg(){
		return 'Simbolo de Unidad Borrado Correctamente';
	}

	//Conceptos
	function getConceptosSuccessMsg(){
		return 'Concepto Creado Correctamente';
	}
	function getConceptosUpdateMsg(){
		return 'Concepto Actualizado Correctamente';
	}
	function getConceptosDeleteMsg(){
		return 'Concepto Borrado Correctamente';
	}

	//Unidades
	function getUnidadesSuccessMsg(){
		return 'Unidad Creada Correctamente';
	}
	function getUnidadesUpdMsg(){
		return 'Unidad Actualizada Correctamente';
	}
	function getUnidadesNotUpdMsg(){
		return 'No Hubo Nada Que Actualizar a la Unidad';
	}
	function getHistoricoUnidad(){
		return 'Historico de la Unidad Agregado';
	}
	function getUnidadesLiberarMsg(){
		return 'Unidad Liberada Correctamente';
	}
	function getUnidadesBloquearMsg(){
		return 'Unidad Bloqueada Correctamente';
	}
	function getUnidadesTrap003Msg(){
		return 'Cambio de Estatus De La Unidad Correcto';
	}
	function getUnidadesDetencionDistribuidor($distribuidor){
		return 'Unidades del Distribuidor '.$distribuidor.' Detenidas Correctamente';
	}
	function getUnidadesDetencionSimbolo($simbolo){
		return 'Unidades con el Simbolo '.$simbolo.' Detenidas Correctamente';
	}
?>
